<template>
  <div>
    <h2>Welcome To Ik Monitor DIY</h2>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>