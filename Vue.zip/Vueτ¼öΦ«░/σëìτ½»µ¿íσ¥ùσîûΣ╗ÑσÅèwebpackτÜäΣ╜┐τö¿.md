



# 前端模块化以及webpack的使用

## 一、前端模块化

- 前端模块化的方案：`AMD`,`CMD`,`CommonJS`,`ES6`
- 在`ES6`之前，我们想要进行模块化开发，就必须借助于其他的工具，让我们可以进行模块化开发
- 并且在通过模块化开发完项目之后，还需要处理各个模块之间的依赖以及最后的模块打包
- 而`Webpack`能够很好的处理模块之间的依赖关系，从而是我们前端开发更容易
- `Webpack`不仅可以打包JavaScript，还可以对CSS，图片，json文件进行打包，这就是`Webpack`的模块化

### （1）打包如何理解

- 就是将`Webpack`中的各种资源模块进行打包合并成一个或多个包（buddle）
- 并且在打包的过程中，还可以对资源进行处理。比如压缩图片，将scss转成css，将ES6语法转成ES5语法，将TypeScript转成JavaScript等等操作

## 二、webpack安装

- 安装webpack首先需要安装Node.js，Node.js自带了软件包管理工具`npm`

- 查看自己node的版本

    `node -v`

- 全局安装webpack（这里先指定版本号3.6.0，因为vue cli2依赖该版本）

    `npm install webpack@3.6.0 -g`

- 局部安装webpack

    - `--save-dev`是开发时依赖，项目打包后不需要继续使用的。

    `cd 对应目录`

    `npm install webpack@3.6.0 --save-dev`

- 为什么全局安装之后，还需要局部安装呢？

    - 在终端直接执行webpack命令，使用的是全局安装的webpack
    - 当在package.json中定义了script时，其中包含了webpack命令，那么使用的是局部webpack

## 三、webpack简单使用

### （1）js文件的打包

- CommonJS的导入和导出

    ![image-20200130101240227](前端模块化以及webpack的使用.assets/image-20200130101240227.png)

- ES6的导入和导出

    <img src="前端模块化以及webpack的使用.assets/image-20200130102545155.png" alt="image-20200130102545155" style="zoom:50%;" />

![image-20200130100640719](前端模块化以及webpack的使用.assets/image-20200130100640719.png)

### （2）入口和出口

- 我们考虑一下，如果每次使用webpack的命令都需要写上入口和出口作为参数，就非常麻烦，有没有一种方法可以将这两个参数写到配置中，在运行时，直接读取呢？

- 当然可以！就是创建一个`webpack.config.js`文件

    ```javascript
    const path = require('path') // 导入path模块
    
    module.exports = {
      // 入口：可以是字符串/数组/对象，这里我们入口只有一个，所以写一个字符串即可
      entry: './src/main.js',
      // 出口：通常是一个对象，里面至少包含两个重要属性，path和filename
      output: {
        // path是动态获取路径
        path: path.resolve(__dirname,'dist'), //注意：path通常是一个绝对路径
        filename: 'bundle.js'
      }
    }
    ```

- 一旦使用node.js中的包时，一定要`npm init`，对项目进行一个包管理。这时会生成一个`package.json`文件，这个文件是告诉我们当前项目的信息的。如果`package.json`文件中，有依赖的包的话，就直接`npm install`，会自动帮你安装需要的依赖

- 为你的`package.json`文件添加一些脚本

    ![image-20200130105542365](前端模块化以及webpack的使用.assets/image-20200130105542365.png)

### （2）CSS文件打包

1. 什么是loader？

    - loader是webpack中一个非常核心的概念
    - webpack用来做什么呢？
        - 处理js文件
        - 处理css、图片、高级ES6语法，以及将jsx、vue文件转成js文件等等
        - 此时，需要添加webpack扩展loader

2. loader的使用过程：

    - 通过`npm`安装需要使用的loader
    - 在webpack.config.js中的modules关键字下，进行配置

3. 大部分loader我们都可以在webpack的官网中找到，并且学习对应的用法

4. 想要webpack能够打包CSS文件，就需要先安装对应的loader

    - 安装

        ```shell
        npm install --save-dev style-loader
        npm install --save-dev css-loader
        ```

    - 在`main.js`文件中，导入对应的css文件

        <img src="前端模块化以及webpack的使用.assets/image-20200130125553413.png" alt="image-20200130125553413" style="zoom:50%;" />

    - 在webpack.config.js中的modules关键字下，进行配置

        - `css-loader`只负责将css文件进行加载
        - `style-loader`负责将样式添加到DOM中
        - 但是，webpack.config.js文件内部解析顺序是从右往左，因此`style-loader`放前面，`css-loader`放后面，先加载后添加到DOM。

        <img src="前端模块化以及webpack的使用.assets/image-20200130125748980.png" alt="image-20200130125748980" style="zoom:50%;" />

    - 执行`npm run build`

        

### （3）less文件处理

- 如果我们希望在项目中使用less、scss、stylus来写样式，webpack是否可以帮助我们处理呢？

    - 这里以less为例，其他也是一样的

- 我们还是先创建一个less文件，依然放在CSS文件夹中，进行相关的代码编写

    <img src="前端模块化以及webpack的使用.assets/image-20200130153136583.png" alt="image-20200130153136583" style="zoom:50%;" />

- 然后安装less对应的loader

    ```shell
    npm install --save-dev less-loader less
    ```

- 去`webpack.config.js`文件中配置module

    ![image-20200130192958460](前端模块化以及webpack的使用.assets/image-20200130192958460.png)

### （4）资源处理

- 图片

    - 在css中通过`url`导入的图片，要下载`url-loader`，如果图片较大大于8k，那么还要安装`file-loader`

        ```shell
        npm install --save-dev url-loader
        npm install --save-dev file-loader
        ```

    - 在css文件中，导入图片

        <img src="前端模块化以及webpack的使用.assets/image-20200130193152898.png" alt="image-20200130193152898" style="zoom:50%;" />

    - 在`webpack.config.js`文件中配置

        ![image-20200130193417029](前端模块化以及webpack的使用.assets/image-20200130193417029.png)

    - 如果图片大于8k，会直接走`file-loader`，在dist里面生成压缩后的图片

        ![image-20200130193601536](前端模块化以及webpack的使用.assets/image-20200130193601536.png)

    - 但是浏览器在加载这些图片的时候，是获取不到这些图片的。因此，要在出口的位置，添加一个配置

        `filePath: 'dist/'`

        <img src="前端模块化以及webpack的使用.assets/image-20200130193815735.png" alt="image-20200130193815735" style="zoom:50%;" />

    - 图片文件处理——修改文件名称

        - 我们发现webpack自动版本我生成一个非常长的名字

            - 这是一个32位hash值，目的是防止名字重复
            - 但是，真是开发中，我们可能对打包图片名字有一定的要求
            - 比如，将所有的图片放在一个文件夹中，跟上图片原来的名称，同时也要防止重复`img/name`

        - 所以，我们可以在`options`中添加上如下选项：

            - img：文件要打包到的文件夹
            - name：获取图片原来的名字，放在该位置
            - Hash8：为了防止图片名称冲突，依然使用hash，但是我们只保留8位
            - ext：使用图片原来的扩展名

        - 但是，我们发现图片并没有显示出来，这是因为路径不正确

            - 默认情况下，webpack会将生成的路径直接返回给使用者

            - 但是，我们整个程序是打包在dist文件夹中的，所以这里我们需要在路径下在添加一个`dist/`

                ![image-20200130200457906](前端模块化以及webpack的使用.assets/image-20200130200457906.png)

## 四、webpack之ES6语法处理

- 如果你仔细阅读webpack打包的js文件，会发现写的ES6语法并没有转成ES5，那么就意味着可能一些对ES6还不支持的浏览器没有办法很好的运行我们的代码。

- 如果希望将ES6的语法很好的转成ES5，那么就需要使用`babel`

    - 而在webpack中，我们直接使用`babel`对应的loader就可以了

        ```shell
        npm install --save-dev babel-loader@7 babel-core
        ```

- 配置`webpack.config.js`文件

    ```json
    {
      test: /\.m?js$/,
      exclude: /(node_modules|bower_components)/,
      use: {
        loader: 'babel-loader',
        options: {
          presets: ['es2015']
        }
      }
    }
    ```

- 重新打包，查看`bundle.js`文件，发现其中的内容变成了ES5的语法

## 五、使用vue的配置

- 后续项目中，我们会使用Vuejs进行开发，而且会以特殊的文件来组织vue的文件

    - 所以，下面我们来学习一下如何在我们的webpack环境中集成Vuejs

- 首先，安装Vuejs的依赖

    - 注：因为我们后续在实际项目中也会使用vue，因此并不是开发时依赖

        ```shell
        npm install vue --save
        ```

- 那么，接下来就可以按照我们之前学习的方式来使用vue了

    ```javascript
    import Vue from 'vue'
    ```

    <img src="前端模块化以及webpack的使用.assets/image-20200131104311065.png" alt="image-20200131104311065" style="zoom:50%;" />

## 六、Vue终极使用方案

如果一个Vue实例中，既有`el`，又有`template`，那么`template`对应的模板会替换掉`el`指向的模板。

- `.vue`文件的封装处理

    - 安装`vue-loader` 和 `vue-template-compiler`

        ```shell
        npm install vue-loader vue-template-compiler --save-dev
        ```

    - 修改`webpack.config.js`的配置文件

        ```json
        {
          test: /\.vue$/,' '
          use: ['vue-loader']
        }
        ```

        ![image-20200131122156435](前端模块化以及webpack的使用.assets/image-20200131122156435.png)

    - 生成`.vue`文件的时候，内部的`name`属性，一定要有

        <img src="前端模块化以及webpack的使用.assets/image-20200131124456235.png" alt="image-20200131124456235" style="zoom:50%;" />

    - `webpack.config.js`的全部配置
    
        ```javascript
        // webpack配置文件
        const path = require("path");
        const { VueLoaderPlugin } = require("vue-loader");
        const webpack = require('webpack');
        const HtmlWebpackPlugin = require('html-webpack-plugin');
        
        module.exports = {
          entry: "./src/main.js",
          output: {
            path: path.resolve(__dirname, "dist"),
            filename: "bundle.js",
            // 下面这个转化html的时候要 注释掉，否则会影响界面显示
            // publicPath: "dist/"
          },
          module: {
            rules: [
              {
                test: /\.css$/,
                use: [
                  {
                    loader: "style-loader"
                  },
                  {
                    loader: "css-loader"
                  }
                ]
              },
              {
                test: /\.less$/,
                use: [
                  {
                    loader: "style-loader" // creates style nodes from JS strings
                  },
                  {
                    loader: "css-loader" // translates CSS into CommonJS
                  },
                  {
                    loader: "less-loader" // compiles Less to CSS
                  }
                ]
              },
              {
                test: /\.(png|jpg|gif|jpeg)$/,
                use: [
                  {
                    loader: "url-loader",
                    options: {
                      esModule: false,
                      // 当加载的图片小于limit时，会将图片编译成base64的格式
                      // 当加载的图片大于limit时，会使用file-loader模块进行加载
                      limit: 8192,
                      name: "img/[name].[hash:8].[ext]"
                    }
                  }
                ]
              },
              {
                test: /\.vue$/,
                use: ["vue-loader"]
              }
            ]
          },
          resolve: {
            // 别名
            alias: {
              vue$: "vue/dist/vue.esm.js"
            },
            extensions: ['.js','.vue','.css']
          },
          plugins: [
            new VueLoaderPlugin(),
            new webpack.BannerPlugin('最终版权归GG所有'),
          	new HtmlWebpackPlugin({
              template:'index.html'
            })
          ]
        };
        
        ```
    
    ## 七、认识plugin
    
    - loader和plugin的区别
    
        - loader主要用于转换某些类型的模块，它是一个转换器
        - plugin是一个插件，它是对webpack本身的扩展，是一个扩展器
    
    - plugin的使用过程
    
        - 步骤一：通过npm安装需要使用的plugins
        - 步骤二：在`webpack.config.js`中的plugins中配置插件
    
    - **添加版权的plugin**
    
        - 插件名字：`BannerPlugin`，属于webpack自带的插件
    
        - 按照下面方式修改`webpack.config.js`文件
    
            ```javascript
            const path = require('path')
            const webpack = require('webpack')
            
            module.exports = {
              ...
              plugins: [
                new webpack.BannerPlugin('最终版权归GG所有')
              ]
            }
            ```
    
        - 重新打包程序：查看bundle.js文件的头部，看到如下信息：
    
            <img src="前端模块化以及webpack的使用.assets/image-20200201111834060.png" alt="image-20200201111834060" style="zoom:50%;" />
    
    - **打包html的plugin**
    
        - 要将index.html文件打包到dist文件中，这个时候就可以使用HTMLWebpackPlugin插件
    
        - HtmlWebpackPlugin插件可以为我们做这些事情：
    
            - 自动生成一个index.html文件（可以指定模板来生成）
            - 将打包的js文件，自动通过script标签插入到body中
    
        - 安装HTMLWebpackPlugin插件
    
            ```shell
            npm install html-webpack-plugin --save-dev
            ```
    
        - 使用插件，修改`webpack.config.js`文件中plugins部分内容如下：
    
            ```javascript
            plugins: [
              new htmlWebpackPlugin({
                template: 'index.html'
              })
            ]
            ```
    
            - `template`表示根据什么模板来生成index.html
            - 另外，我们需要删除之前在output中添加的publicPath属性
            - 否则，插入的script标签中的src可能会有问题
    
    - **js压缩的Plugin**
    
        - 在项目发布之前，我们必然需要对js等文件进行压缩处理
    
            - 这里我们就对打包的js文件进行压缩
    
            - 我们使用一个第三方的插件`uglifyjs-webpack-plugin`，并且版本号指定1.1.1，和CLI2保持一致
    
                ```shell
                npm install uglifyjs-webpack-plugin@1.1.1 --save-dev
                ```
    
            - 修改`webpack.config.js`文件，使用插件：
    
                ```javascript
                const uglifyJsPlugin = require('uglifyjs-webpack-plugin')
                
                module.exports = {
                  ...
                  new uglifyJsPlugin()
                }
                ```
    
            - 查看打包后的文件`bundle.js`文件，是已经被压缩过了