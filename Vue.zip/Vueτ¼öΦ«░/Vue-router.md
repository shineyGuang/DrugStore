# Vue-router

## 一、认识路由

- 路由是决定数据包从**来源**到**目的地**的路径
- 传送将**输入端**的数据转移到合适的**输出端**
- 路由中有一个非常重要的概念叫**路由表**
    - 路由表本质上就是一个映射表，决定了数据包的指向
- 什么是**前端渲染**，和 **后端渲染**？
    - 后端渲染：就是从后端动态读取数据，并且将它动态的放在页面中
    - 前端渲染：浏览器中显示的网页中的大部分内容，都是由前端写的js代码在浏览器中执行，最终渲染出来的网页

## 二、`vue-router`基本使用

- `vue-router`是Vue.js官方的路由插件，它和`vue.js`是深度集成的

- **安装和使用`vue-router`**

    ```shell
    npm install vue-router --save
    ```

    - 在模块化工程中使用它（因为它是一个插件，所以可以通过`vue.use()`来安装路由功能）
        1. **导入**路由对象，并且**调用`Vue.use(vueRouter)`**
        2. 创建**路由实例**，并且传入路由**映射配置**
        3. 在**Vue实例**中**挂载**创建的**路由实例**

- **配置路由相关信息**

    ```js
    import VueRouter from 'vue-router'
    import Vue from 'vue'
    
    // 1.通过Vue.use(插件)，安装插件
    Vue.use(VueRouter)
    
    // 2.创建VueRouter对象
    const routes = [
      url: '地址'
    ]
    const router = new VueRouter({
      // 配置路径和组件之间的应用关系
      routes
    })
    // 3.将router对象传入到Vue实例中
    export default router
    ```

- **使用`vue-router`的步骤**

    - 第一步：创建路由组件

        <img src="/Users/zhaochenguang/Library/Application Support/typora-user-images/image-20200202184113329.png" alt="image-20200202184113329" style="zoom:50%;" />

    - 第二步：配置路由映射-->组件和路径映射的关系

        <img src="/Users/zhaochenguang/Library/Application Support/typora-user-images/image-20200202190306258.png" alt="image-20200202190306258" style="zoom:50%;" />

        <img src="/Users/zhaochenguang/Library/Application Support/typora-user-images/image-20200202190715568.png" alt="image-20200202190715568" style="zoom:50%;" />

    - 第三步：使用路由-->通过`<router-link> 和 <router-view>`

        <img src="/Users/zhaochenguang/Library/Application Support/typora-user-images/image-20200202184623480.png" alt="image-20200202184623480" style="zoom:50%;" />

- **`router-link`补充**

    - `to`：用于指定跳转的路径
    - `tag`：tag可以指定`<router-link>`之后渲染成什么组件，比如`tag="button"`
    - `replace`：这个属性可以取消html5的history记录
    - `active-class`：当`<router-link>`对应的路由匹配成功时，会自动给当前元素设置一个`router-link-active`的class，设置`active-class`可以修改默认的名称
        - 在进行高亮显示的导航菜单或者底部tabbar时，会使用到该类
        - 但是通常不会修改类的属性，会直接使用默认的`router-link-active`即可
    - 通过代码修改路由
        - `this.$router.push('/home')`
        - `this.$router.replace('/home')`
    
- **动态路由** 

    - 比如有一个用户页面，不同的用户登录的url不同，到用户页面显示的内容也不同，那么就需要动态路由了

    - 第一步：先创建用户页面组件

        <img src="Vue-router.assets/image-20200203110406907.png" alt="image-20200203110406907" style="zoom:50%;" />

    - 第二步：在`router/index.js`中配置组件和路由绑定信息

        <img src="Vue-router.assets/image-20200203110657696.png" alt="image-20200203110657696" style="zoom:50%;" />

    - 第三步：在`<router-link>`中，进行属性绑定

        <img src="Vue-router.assets/image-20200203110907465.png" alt="image-20200203110907465" style="zoom:50%;" />

- `vue-router`**打包文件的解析**

    - app乱码.js  业务代码
    - manifest乱码.js  底层支撑
    - vendor乱码.js  三方支撑

- **认识路由的懒加载**

    - 官方给出的解释：

        - 当打包构建应用时，javascript包会变得很大，影响页面加载
        - 如果我们能把不同路由对应的组件分割成不同的代码块，然后当路由被访问的时候才加载对应的组件，这样就更加高效了

    - 路由懒加载做了什么？

        - 路由懒加载的主要作用就是将路由对应的组件打包成一个个js代码块
        - 只有在这个路由被访问到的时候，才加载对应的组件

    - 写法：

        - 一个路由对应一个懒加载

        <img src="Vue-router.assets/image-20200203190311645.png" alt="image-20200203190311645" style="zoom:50%;" />

## 三、`vue-router`嵌套路由

- 嵌套路由是一个很常见的功能

    - 比如在home页面中，我们希望通过`/home/news 和 /home/message`访问一些内容
    - 一个路径映射一个组件，访问这两个路径也会分别渲染两个组件

- 路径和组件的关系如下：

    <img src="Vue-router.assets/image-20200203191648976.png" alt="image-20200203191648976" style="zoom:50%;" />

- **实现嵌套路由有两个步骤**：

    - 创建对应的子组件，并且在路由映射中配置对应的子路由
    
    - 在组件内部使用`<router-view>`标签
    
        <img src="Vue-router.assets/image-20200204135555757.png" alt="image-20200204135555757" style="zoom:50%;" />

## 四、`vue-router`参数传递

- **路由传递参数**

    - **params的类型**

        - 配置路由格式：`/router/:id`
        - 传递的方式：在path后面跟上对应的值
        - 传递后形成的路径：`/router/123, /router/abc`

    - **query的类型**

        - 配置路由格式：`/router`，也就是普通配置

        - 传递方式：对象中使用`query`的`key`作为传递方式

        - 传递后形成的路径：`/router?id=123，/router?id=abc`

            <img src="Vue-router.assets/image-20200204110747766.png" alt="image-20200204110747766" style="zoom:50%;" />

            <img src="Vue-router.assets/image-20200204114840301.png" alt="image-20200204114840301" style="zoom:50%;" />

- `$router`和`$route`是有区别的

    - 所有的组件都继承自Vue的原型

    - `$route`表示当前活跃的路由，那个路由活跃就把这个路由赋值给`$route`

    - `$router`表示路由对象，其中有很多种方法

        <img src="Vue-router.assets/image-20200205124428226.png" alt="image-20200205124428226" style="zoom:50%;" />

## 五、`vue-router`导航守卫

- 需求：当我点击每一个组件时，标题要随之发生改变。因此就要用到导航守卫。

- 代码实现：

    <img src="Vue-router.assets/image-20200204131428466.png" alt="image-20200204131428466" style="zoom:50%;" />

- 上面我们使用的导航守卫，被称为全局守卫。还有两种守卫

    - 路由独享守卫
    - 组件内的守卫

## 六、`keep-alive`

- `keep-alive`是vue内置的一个组件，可以使被包含的组件保留状态，或者避免重新渲染
    - include - 字符串或者正则表达式，只有匹配的组件会被缓存
    - exclude - 字符串或者正则表达式，任何匹配的组件都不会被缓存
- `router-view`也是一个组件，如果直接被包在`keep-alive`里面，所有路径匹配到的视图组件都会被缓存 
- <img src="Vue-router.assets/image-20200204150821848.png" alt="image-20200204150821848" style="zoom:50%;" />

- 给组件添加上name，然后可以让组件在`keep-alive`中被排除掉

    <img src="Vue-router.assets/image-20200204151449154.png" alt="image-20200204151449154" style="zoom:50%;" />

- 通过`create`声明周期函数来验证 