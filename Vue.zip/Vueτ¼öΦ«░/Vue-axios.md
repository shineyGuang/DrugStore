# Vue-axios

- 支持多种请求方式

    - `axios(config)`
    - `axios.request(config)`
    - `axios.get(url,config)`
    - `axios.delete(url,config)`
    - `axios.head(url,config)`
    - `axios.post(url,[,data[,config]])`
    - `axios.put(url,[,data,[config]])`
    - `axios.patch(url,[,data,[config]])`

- 123.207.32.32:8000/home/multidata

- 实现代码：

    ```js
    axios({
      url: 'http://123.207.32.32:8000/home/date',
      // 专门针对get请求的参数拼接
      params: {
      	type: 'pop',
        page: 1
      }
    }).then(res => {
      console.log(res);
    })
    ```

- 处理并发请求

    ```js
    axios.all([axios(
    	url: 'http://123.207.32.32:8000/home/date',
      params: {
      	type: 'sell',
      	page: 4
      }
    ),axios(
    	url: 'http://123.207.32.32:8000/home/multidata'
    )]).then(axios.spread((res1,res2) => {
      // 处理
      console.log(res1);
      console.log(res2)
    })
    ```

- 全局配置

    ```js
    axios.defaults.baseURL = '123.207.32.32:8000'
    axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencode'
    ```

    - 常见配置项：
        - 请求地址
            - url:'/user'
        - 请求类型
            - `method:'get'`
        - 根路径
            - `baseURL: 'http://www.mt.com/api'`
        - 请求前的数据处理
            - `transformRequest:[function(data){}]`
        - 请求后的数据处理
            - `transformResponse:[function(data){}]`
        - 自定义的请求头
            - `headers:{'x-Requested-With':XMLHttpRequest'}`
        - URL查询对象
            - `params:{id:2}`

- 创建对应的axios实例

    ```js
    const instance1 = axios.create({
      baseURL:"xxx",
      timeout: 5000,
      //headers:{}
    })
    instace1({
      url: "/home",
    }).then(res => {
      console.log(res)
    })
    ```

- axios的封装

    ```js
    // network/request.js
    import axios from 'axios'
    
    export function request(config) {
      // 1.创建axios实例
      const instance = axios.create({
        baseURL: 'http://123.203.32.32:8000',
        timeout: 5000
      });
      // 发送真正的网络请求
      return instance(config)
    }
    ```

    ```js
    // 使用封装
    import {request} from './network/request';
    
    request({
     	url: '/home/multidata'
    }).then(res => {
      console.log(res);
       
    }).catch(err => {
      console.log(err);
    })
    ```

- 如何使用拦截器

    ```js
    // 配置请求和响应拦截
    instance.interceptors.request.use(config => {
      console.log("来到了request拦截success中");
      return config //拦截处理之后，一定要返回，否则报错
    }, err => {
      console.log("来到了request拦截failure中");
      return err
    })
    
    instance.interceptors.response.use(response => {
      console.log("来到了response拦截success中");
      return response.data
    }, err => {
    	console.log("来到了response拦截failure中");
      return err
    })
    ```

- 完整版

    ```js
    import axios from 'axios'
    
    export function request(config) {
      //1.创建axios实例
      const instance = axios.create({
        baseURL: 'http://123.207.32.32:8000',
        timeout: 5000
      });
    
      //2.拦截器
      //2.1请求拦截器
      instance.interceptors.request.use(config => {
        return config
      }, error => {
        console.log(error);
      });
    
      //2.2响应拦截
      instance.interceptors.response.use(res => {
        return res.data
      },error => {
        console.log(error);
      });
    
      //3.发送真正的请求
      return instance(config)
    }
    ```

- 二次封装

    ```js
    import {request} from "./request";
    
    export function getHomeMultiData() {
      return request({
        url: '/home/multidata'
      })
    }
    ```

- 在created中使用

    ```js
    getHomeMultiData().then(res => {
            this.banners = res.data.banner.list;
            this.recommends = res.data.recommend.list;
          })
    ```

    