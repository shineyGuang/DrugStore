# Vue-CLI

## 一、什么是vue-cli

- 当你开发大型项目的时候，需要使用vue-cli
- 如果每个项目都要手动完成这些工作，那么为了提高效率也需要使用脚手架
- 使用vue-cli可以快速搭建Vue开发环境以及对应的webpack配置

## 二、vue-cli使用前提-node

- 要求版本node -v 8.9以上

## 三、vue-cli的使用

- 安装vue脚手架

    ```shell
    cnpm install -g @vue/cli
    ```

- vue-cli初始化项目

    - Cli2：`vue init webpack my-project`
    - Cli3: `vue create my-project`
    
- Runtime-Compiler 和 Runtime-only的区别

    - 如果在开发中，你依然使用template，就需要选择`Runtime-Compiler`
    - 如果使用`.vue`文件开发，那么可以选择`Runtime-only`

- Vue-cli 3 与 vue-cli 2 版本有很大区别

    - vue-cli 3 是基于 `webpack4` 打造
    - vue-cli 3 的设计原则是 `0配置`，移除了配置文件根目录下的`build`、`config`目录
    - vue-cli 3 提供了`vue ui`命令，提供了可视化配置，更加人性化
    - 移除了static文件夹，新增了`public`文件夹，并且`index.html`移到`public`中

## 四、别名的使用

1. 创建项目

2. 在根目录下创建`vue.config.js`

3. 修改`vue.config.js`

    ```js
    // vue.config.js
    module.exports = {
      configureWebpack: {
        resolve: {
          alias: {
            'assets': '@/assets',
            'components': '@/components',
            'views': '@/views',
          }
        }
      },
    }
    ```

4. `@`路径在`/node_modules/@vue/cli-service/lib/config/base.js`中已经配好

5. 在`src`中用到路径的时候要加上`~`

    <img src="Vue-cli.assets/image-20200207142053721.png" alt="image-20200207142053721" style="zoom:50%;" />