# Vue基础

## 一、Vue起步

- 引包

- 启动 `new Vue({el:目的地,template:模板内容})`

- 创建实例化对象

- java中的高阶函数`filter`  `map`  `reduce`

    ```java
    // 共同特点：接受一个回调函数，filter要返回布尔值，map表示将列表里的每一项都作出对应操作，reduce表示聚合，
    // eg.  可以链式编程
    const nums = [10, 20, 30, 444, 33, 21, 779];
    const newNums = nums.filter(function (n) {
        return n < 100;
    }).map(function (n) {
        return n * 2;
    }).reduce(function (preValue, n) {
        return preValue + n;
    },0);
    console.log(newNums);
    
    """
      228
    """
    ```

    

## 二、核心思想

**数据驱动视图**

## 三、插值表达式

- **{{ 表达式 }}**
    - 对象（不要连续三个`{{ {name:"张三"} }}`）
    - 字符串 `{{'xxx'}}`
    - 判断后的布尔值 `{{ true }}`
    - 三元表达式 `{{true?'正确' : '错误'}}`
- 可用于页面简单粗暴的测试
- 注意：必须在data这个函数中返回的对象中声明

## 四、什么是指令？

- 在Vue中提供了一些对于页面 + 数据的更为方便的输出，这些操作就叫做指令，以`v-xxx`表示
    - 比如html页面中的属性，`<div v-xxx></div>`
- 比如在angular中以ng-xxx开头的就叫做指令
- 在Vue中以v-xxx开头的就叫做指令
- 指令中封装了一些DOM行为，结合属性作为一个暗号，暗号有对应的值，根据不同的值，框架会进行相关DOM操作的绑定

## 五、Vue中的常用v-xxx指令的演示

- `v-text`：元素的innerText属性，必须是双标签，跟`{{}}`效果是一样的，使用较少

- `v-html`：元素的innerHTML

- `v-if`：判断是否插入这个元素，相当于对元素的销毁和创建。如果数据属性对应的值为真，就显示；反之，不显示

- `v-else-if`

- `v-else`

- `v-show`：隐藏元素，如果确定要隐藏，会给元素的style加上`display:none`，是基于CSS样式的切换。控制DOM元素的显示隐藏

- `v-bind`：绑定标签上的属性（内置的属性和自定义属性）可以直接用`:`

- `v-on`：原生JS事件名= '函数名'  简便写法：@

    - `V-on`的参数问题：

        - 不需要参数

            ```html
            <button @:click="changeHandler">
            	
            </button>
            <script>
            	new Vue({
                el:'#app',
                data() {
                  return {
                    msg:""
                  }
                },
                methods:{
                  changeHandler() {
                    console.log(this);
                  }
                }
              })
            </script>
            ```

        - 需要传入参数

            ```html
            <button @:click="changeHandler(213)">
            	
            </button>
            <script>
            	new Vue({
                el:'#app',
                data() {
                  return {
                    msg:""
                  }
                },
                methods:{
                  changeHandler(param) {
                    console.log(this);
                    console.log(param);
                  }
                }
              })
            </script>
            ```

        - 需要传入参数，但是绑定的时候不写`()`

            ```html
            <button @:click="changeHandler">
            	
            </button>
            <script>
            	new Vue({
                el:'#app',
                data() {
                  return {
                    msg:""
                  }
                },
                methods:{
                  changeHandler(event) {
                    console.log(this);
                    console.log(event);//会把浏览器产生的event事件对象作为参数传入到方法
                  }
                }
              })
            </script>
            ```

        - 既需要传参，又需要event对象  `$event`

            ```html
            <button @:click="changeHandler(123,$event)">
            	
            </button>
            <script>
            	new Vue({
                el:'#app',
                data() {
                  return {
                    msg:""
                  }
                },
                methods:{
                  changeHandler() {
                    console.log(this);
                  }
                }
              })
            </script>
            ```

    - `v-on`的修饰符

        - `.stop`

            ```html
            <div id="app">
              <div @click="divClick">
               <!-- 这个地方会阻止下面的button冒泡，如果不想用aaa事件阻止，那么就可以用.stop修饰符来终止 -->
                aaaa  
               	<button @click.stop="btnClick">
                  按钮
                </button>
              </div>
            </div>
            ```

        - `.prevent`

            ```html
            <form action="baidu">
              <input type="submit" value="提交" @click.prevent="submitClick"> <!-- 阻止默认行为 -->
            </form>
            ```

        - `.{keyCode|keyAlias}` 只当事件是从特定键触发时才触发回调。

            ```html
            <input @keyup.enter="onEnter">
            <input @keyup.13="onEnter">  <!-- 键位对应的编号 -->
            ```

- `v-for`：`v-for = "(item,index) in menulists"`

- `v-model`：v-model 双向数据绑定的体现 只会体现在UI控件中，只能应用在有value属性的。语法糖，就是`v-bind 和 v-for` 的体现。

    ```html
    <input type="text" v-model="message"> 等价于 
    <input type="text" v-bind:value="message" v-on:input="message=$event.target.value">
    ```

    

## 六、v-if  和  v-show 的区别

- `v-if`是真正的条件渲染，因为它会确保在切换过程中，条件块内的事件监听器和子组件适当地被销毁和重建。

    `v-if`也是惰性的：如果在初始渲染时条件为假，则什么也不做。直到条件变为真时，才会开始渲染事件块。

- 相比之下，`v-show`就简单很多，不管初始条件是什么，元素总是被渲染，并且只是简单地基于CSS进行切换。

- 一般来说，`v-if`有更高的切换开销，而`v-show`有更高的初始渲染开销。因此，如果需要非常频繁的切换，则使用`v-show`最好；如果在运行时条件很少改变，则使用`v-if`较好。

## 七、组件

## 八、生命周期