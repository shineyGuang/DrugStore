# vuex详解

- 官方解释：Vuex是一个专门为`vue.js`应用程序开发的**状态管理模式**
    - 它采用**集中式存储管理**应用所有的组件的状态，并以相应的规则保证状态以一种可预测的方式发生变化
    - Vuex也集成到Vue官方调试工具`devtools extension`，提供了诸如零配置的`time-travel`调试、状态快照导入导出等高级调试功能。
- 状态管理到底是什么？
    - 把需要多个组件共享的变量全部存储在一个对象里面
    - 然后，将这个对象放在顶层的Vue实例中，让其它组件可以使用
- 管理哪些状态？
    - 登录状态、头像、地理位置
    - 商品的收藏、购物车中的物品

## 一、单页面的状态管理

- 二话不说先上图

    <img src="vuex详解.assets/image-20200207172139306.png" alt="image-20200207172139306" style="zoom:50%;" />

- 创建一个名为`store`的文件夹，创建`index.js`

    ```js
    import Vue form 'vue'
    import Vuex from 'vuex'
    
    // 1.安装插件
    Vue.use(Vuex);
    
    // 2.创建对象
    const store = new Vuex.Store({
      state: {
        couter
      },
      mutations: {
        // 同步的操作// 方法 state自动的传过来，只有走mutations，devtools才能检测到每一步的结果
        increment(state) {
          state.couter ++
        },
        decrement(state) {
          state.counter --  
        }
      },
      actions: {
        // 如果有异步操作，到这里放变量
      },
      getters: {
        
      },
      modules: {
        
      }
    });
    
    // 3.导出store对象
    export default store
    ```

    ```js
    main.js 挂载
    
    import store from './store'
    ```

    - 传值

        <img src="vuex详解.assets/image-20200207183840058.png" alt="image-20200207183840058" style="zoom:50%;" />
        
    - vuex中mutation方法的挂载

        <img src="vuex详解.assets/image-20200207184140255.png" alt="image-20200207184140255" style="zoom:50%;" />

- Vuex状态管理图例

    <img src="vuex详解.assets/image-20200207174250934.png" alt="image-20200207174250934" style="zoom:50%;" />

- 小结：
    1. 提取出一个公共的store对象，用于保存在多个组件中共享的状态
    2. 将store对象放置在`new Vue`对象中，这样可以保证在所有的组件中都可以使用到
    3. 在其它组件中使用store对象中保存的状态即可
        - 通过`this.$store.state.属性`的方式来访问状态
        - 通过`this.$store.commit('mutations中的方法')`来修改状态
    4. 注意事项：
        - 我们通过提交mutations的方式，而非直接改变`$store.state.属性`
        - 这是因为`Vuex`可以更明确的追踪状态的变化，所以不要直接改变`$store.state.属性`的值

## 二、Vuex的核心概念

- State

    - 单一状态树

- Getters

    - 基本使用

        ![image-20200207192327987](vuex详解.assets/image-20200207192327987.png)
        
        <img src="vuex详解.assets/image-20200208084651477.png" alt="image-20200208084651477" style="zoom:50%;" />

- Mutations

    - 状态更新：唯一更新方式，提交Mutation

    - Mutations主要包括两个部分：

        - 字符串的事件类型 type

        - 一个回调函数（handler），该回调函数的第一个参数就是state

            <img src="vuex详解.assets/image-20200208094157242.png" alt="image-20200208094157242" style="zoom:50%;" />

    - Mutation传递参数

        - 在通过mutation更新数据的时候，有可能我们希望携带一些额外的参数
            - 参数被称为是mutation的载荷（payload）
            - 如果参数不是一个，那么就传一个对象

    - Mutations的提交风格

        - commit

        - 包含一个type属性的对象

            <img src="vuex详解.assets/image-20200208100812536.png" alt="image-20200208100812536" style="zoom:50%;" />

    - Mutations的响应规则

        - Vuex中的`store.state`是响应式的，当state中的数据发生改变时，Vue组件会自动更新
        - 这就要求我们必须遵守一些Vuex对应的规则：
            - 提前在store中初始化号所需的属性
            - 当给state中的对象添加新属性时，使用下面的方式：
                - 使用`Vue.set(obj,'newProp',123)`
                - 使用`Vue.delete(obj,'Prop')` 

    - Mutations最好写成常量

    - Mutations同步函数，如果有异步操作，就用Action

- Actions 

    - 代码：

        ```js
        actions: {
          // context 上下文
          aUpdateInfo(context) {
            setTimeout(() => {
              context.commit('updateInfo')
            },1000)
          }
        }
        
        // App.vue
        updateInfo() {
          this.$store.dispatch('aUpdateInfo')
        }
        ```

    - 带参数

        ```js
        actions: {
          // context 上下文
          aUpdateInfo(context, payload) {
            return new Promise(resolve,reject) => {
              setTimeout(() => {
              context.commit('updateInfo');
              console.log(payload.message);
              resolve('11111')
            },1000)
            }
          }
        }
        
        // App.vue
        updateInfo() {
         	this.$store
          	.dispatch('aUpdateInfo','我是携带的信息')
          	.then(res => {
            	console.log('里面完成了提交')
            	console.log(res);
          })
        }
        ```

    - 说白了就是改数，一定要在mutation中修改，但是出现异步操作了，就需要在action中去提交mutation中的对应方法 

- Module 

    - 为了避免store臃肿，Vuex允许我们将store分割成模块`module`，而每个模块拥有自己的state、mutations、actions、getters等
    - `{{$store.state.a.name}}`