# Vue父传子和子传父总结

## 结构

```html
<div id="app">

  <h2>
    我是父组件
  </h2>
  
  <!-- 子组件 -->
  <cpn></cpn> 

</div>

<template id="cpn">
	<div>
    <!-- 写入子组件内容 -->
  </div>
</template>

<script>

// 先声明一个vue实例
  const app = new Vue({
    // 地主家包的那块地
    el: "#app",
    data () {
      return {
        // 这个位置放数据
      }
    },
    components:{
      // 组件在者开始写
      cpn:{
        // 切记组件没有el
        template: "#cpn"
        // 指定模板，名字：模板相关options
        data() {
          return {
            // 这个地方是组件的数据
          }
        },
      }
    }
  })
  
</script>
```

## 父传子  `props`

```html
<div id="app">

  <h2>
    我是父组件
  </h2>
  
  <!-- 子组件 -->
  <cpn :cbooks="books"></cpn>  

</div>

<template id="cpn">
	<div>
    <!-- 写入子组件内容 -->
    <ul>
      <li v-for="(item,index) in cbooks" :key="index">{{item.name}}</li>
    </ul>
  </div>
</template>

<script>
	// 就是将父组件的数据，通过v-bind将数据传给子组件的一个属性，这个属性要在props中去定义
  const app = new Vue({
    // 地主家包的那块地
    el: "#app",
    data () {
      return {
        books:[
          // 有很多书
        ]
      }
    },
    components:{
      cpn:{
        template:"#cpn",
        data() {
          return {
            
          }
        },
        // 父传子通过props传递
        props:{
          cbooks:Array
        }
      }
    }
  })

</script>
```

## 子传父`$emit("自定义方法，挂载到子组件","传参")`

```html
<!-- 计数器小案例 -->

<div id="#app">
  <h1>{{total}}</h1>
  <cpn :increment="changeTotal" :decrement="changeTotal"></cpn>
</div>

<template>
  <div>
    <button @click="decrement">-</button>
    <button @click="increment">+</button>
  </div>
</template>

<script>

  const app = new Vue({
    el: "app",
    data() {
      return {
        total:0
      }
    },
    // 父组件的方法
    methods: {
      changeTotal(val) {
        this.total = val;
      }
    }
    components: {
      cpn:{
        template:"#cpn",
        data() {
          currentVal:0
        },
        methods: {
          increment() {
            this.currentVal += 1;
            //this.$emit("自定义方法名，在子组件上挂载","传参")
            this.$emit("increment",this.currentVal);
          },
          decrement() {
            this.currentVal -= 1;
            this.$emit("decrement",this.currentVal);
          }
        }
      }
    }
  })

</script>
```



