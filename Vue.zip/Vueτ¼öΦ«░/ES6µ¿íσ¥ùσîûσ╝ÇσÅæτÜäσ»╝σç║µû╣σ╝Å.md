# ES6模块化开发的导出与导入方式

1. 直接导出

    ```javascript
    export {
    	flag,num
    }
    ```

2. 导出时声明变量

    ```javascript
    export var name = "GG"
    ```

3. 导出函数或者类

    ```javascript
    export function mul(num1,num2) {
      return num1 * num2
    }
    
    export class Person() {
      run() {
        console.log("He is running!")
      }
    }
    
    import Person from "xxx.js"
    var p = Person()
    Person.run()
    ```

4. `export default`

    ```javascript
    export default function(arg) {
      console.log(arg)
    }
    
    import aaaa from "xxx.js"
    aaaa("hello,world")
    ```

5. 统一全部导入

    ```javascript
    import * as info from "info.js"
    ```

    