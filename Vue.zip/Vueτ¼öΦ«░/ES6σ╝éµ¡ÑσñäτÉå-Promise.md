# Promise

## 一、什么是Promise？

- ES6中一个非常重要和好用的特性就是Promise
- Promise到底是做什么的呢？
    - Promise**是异步编程的一种解决方案**
- 什么时候需要异步处理事件呢？
    - 一种很常见的场景就是网络请求了
    - 我们封装了一个网络请求的函数，因为不能立即拿到结果，所以不能像简单的1+1=2一样将结果返回
    - 所以我们往往会传入另外一个函数，在数据请求成功后，将数据通过传入的函数回调出去
- 但是，当网络请求非常复杂时，就会出现回调地狱
- Promise可以以一种非常优雅的方式来解决这个问题 

## 二、定时器的异步事件

- 我们先来看一个Promise的最基本的语法

    ```js
    setTimeoute(function() {
      let data = 'Hello World';
      console.log(content);
    }, 1000)
    
    // 这里，我们用一个定时器来模拟异步事件
    	// 假设上面的data就是网络上1秒后请求的数据
    	// console.log就是处理方式
    ```

- Promise代码

    ```js
    new Promise((resolve,reject) => {
      setTimeout(() => {
        // 成功的时候调用，对应then
        resolve('hello World');
        // 失败的时候调用，对应catch
        reject('Error Data')
      }, 1000)
    }).then(data => {
      console.log(data)
    }).catch(error => {
      console.log(error)
    })
    
    // new -> 构造函数（1.保存了一些状态信息 2.执行传入的函数）
    // 在执行传入的回调函数时，会传入两个参数，resolve，reject.本身又是函数
    
    ```

## 三、Promise的三种状态

- `pending`：等待状态，比如正在进行网络请求，或者定时器没有到时间
- `fullfill`：满足状态，当我们主动回调了resolve时，就处于该状态，并且会回调`.then()`
- `reject`：拒绝状态，当我们主动回调了`reject`时，就处于该状态，并且会回调`.catch()`

## 四、Promise的链式调用

```js
new Promise(resolve => {
    setTimeout(() => {
      resolve('aaa')
    },1000)
  }).then(data => {
    console.log(data);
    return new Promise(resolve => {
      resolve(data + '111')
    }).then(data => {
      console.log(data);
      return new Promise(resolve => {
        resolve(data + '222')
      }).then(data => {
        console.log(data);
      })
    })
  })
```

<img src="ES6异步处理-Promise.assets/image-20200207145608662.png" alt="image-20200207145608662" style="zoom:50%;" />

- 简写：

    ```js
    new Promise(resolve => {
        setTimeout(() => {
          resolve('aaa')
        },1000)
      }).then(data => {
        console.log(data);
      //
        return data + '111'  //牛逼
        }).then(data => {
          console.log(data);
      //
          return data + '222'  //牛逼
          }).then(data => {
            console.log(data);
          })
    ```

## 五、Promise的all的使用

- 代码：

    ```js
    Promise.all([
      new Promise((resolve,reject) => {
        $.ajax({
          url:'',
          success: function (data) {
            resolve(data)
          }
        })
      }),
      new Promise((resolve,reject) => {
        $.ajax({
          url: '',
          success: data => {
            resolve(data)
          }
        })
      })
    ]).then(results => {
      results[0],  // 第一个回来的结果
      results[1],  // 第二个回来的结果 
    })
    ```

    