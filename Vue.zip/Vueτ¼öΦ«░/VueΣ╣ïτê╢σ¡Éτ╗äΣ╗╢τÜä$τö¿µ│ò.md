# Vue之父子组件的$用法

## `$children和$refs`

```html
<body>
  <div id="app">
    <cpn ref="aaa"></cpn>
    <cpn></cpn>
    <button @click="btnClick">显示子组件数据</button>
  </div>

  <template id="cpn">
    <div>
      我是子组件
    </div>
  </template>
</body>

<script>

  const app = new Vue({
    el: "#app",
    data() {
      return {
        name:"Kobe Briant"
      }
    },
    methods: {
      btnClick() {
        console.log(this.$children[0]);  // 拿到的是vuecomponent实例，但是如果多个组件就无法区分
        console.log(this.$refs.aaa.name);  // refs 可以通过在标签上加ref="aaa"，也就是赋予一个变量，通过这个变量区分开其他组件。
      }
    }
  })
  
</script>

```

